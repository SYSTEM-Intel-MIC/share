#include<iostream>
#include<windows.h>
std::string a; 
int main(){
	Sleep(10000);
	std::cout<<"���ڽ���";
	system("reg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\" /f");
	system("start.bat");
} 
